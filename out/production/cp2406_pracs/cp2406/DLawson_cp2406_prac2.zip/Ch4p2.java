package cp2406;

/*
The hexadecimal digits are the ordinary, base-10 digits '0' through '9' plus the letters 'A' through 'F'.
In the hexadecimal system, these digits represent the values 0 through 15, respectively.
Write a function named hexValue that uses a switch statement to find the hexadecimal value of a given character.
The character is a parameter to the function, and its hexadecimal value is the return value of the function.
You should count lower case letters 'a' through 'f' as having the same value as the corresponding upper case letters.
If the parameter is not one of the legal hexadecimal digits, return -1 as the value of the function.

A hexadecimal integer is a sequence of hexadecimal digits, such as 34A7, ff8, 174204, or FADE.
If str is a string containing a hexadecimal integer, then the corresponding base-10 integer can be computed as follows:

value = 0;
for ( i = 0; i < str.length();  i++ )
   value = value*16 + hexValue( str.charAt(i) );
Of course, this is not valid if str contains any characters that are not hexadecimal digits.
Write a program that reads a string from the user.
If all the characters in the string are hexadecimal digits,
print out the corresponding base-10 value. If not, print out an error message.
 */

import textio.TextIO;

    /*
     * This program reads a hexadecimal number input by the user and prints the
     * base-10 equivalent.  If the input contains characters that are not
     * hexadecimal numbers, then an error message is printed.
     */

    public class Ch4p2 {

        public static void main(String[] args) {
            String hex;  // Input from user, containing a hexadecimal number.
            long dec;    // Decimal (base-10) equivalent of hexadecimal number.
            int i;       // A position in hex, from 0 to hex.length()-1.
            System.out.print("Enter a hexadecimal number: ");
            hex = TextIO.getlnWord();
            dec = 0;
            for ( i = 0; i < hex.length(); i++ ) {
                int digit = hexValue( hex.charAt(i) );
                if (digit == -1) {
                    System.out.println("Error:  Input is not a hexadecimal number.");
                    return;  // Ends the main() routine.
                }
                dec = 16*dec + digit;
            }
            System.out.println("Base-10 value:  " + dec);
        }  // end main

        /*
         * Returns the hexadecimal value of a given character, or -1 if it is not
         * a valid hexadecimal digit.
         * @param ch the character that is to be converted into a hexadecimal digit
         * @return the hexadecimal value of ch, or -1 if ch is not
         *     a legal hexadecimal digit
         */
        public static int hexValue(char ch) {
            switch (ch) {
                case '0':
                    return 0;
                case '1':
                    return 1;
                case '2':
                    return 2;
                case '3':
                    return 3;
                case '4':
                    return 4;
                case '5':
                    return 5;
                case '6':
                    return 6;
                case '7':
                    return 7;
                case '8':
                    return 8;
                case '9':
                    return 9;
                case 'a':     // Note:  Handle both upper and lower case letters.
                case 'A':
                    return 10;
                case 'b':
                case 'B':
                    return 11;
                case 'c':
                case 'C':
                    return 12;
                case 'd':
                case 'D':
                    return 13;
                case 'e':
                case 'E':
                    return 14;
                case 'f':
                case 'F':
                    return 15;
                default:
                    return -1;
            }
        }  // end hexValue

    }

