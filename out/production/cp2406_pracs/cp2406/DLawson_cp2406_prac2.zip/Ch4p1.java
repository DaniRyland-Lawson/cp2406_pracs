package cp2406;
import  text.TextIO;

    /*
     To "capitalize" a string means to change the first letter of each word in the string to upper case
     (if it is not already upper case). For example, a capitalized version of "Now is the time to act!" is
     "Now Is The Time To Act!".
     Write a subroutine named printCapitalized that will print a capitalized version of a string to standard output.
     The string to be printed should be a parameter to the subroutine.
     Test your subroutine with a main() routine that gets a line of
     input from the user and applies the subroutine to it.

     Note that a letter is the first letter of a word if it is not immediately preceded in the string by another letter.
      Recall from Exercise 3.4 that there is a standard boolean-valued function Character.isLetter(char)
      that can be used to test whether its parameter is a letter. There is another standard char-valued function,
      Character.toUpperCase(char), that returns a capitalized
      version of the single character passed to it as a parameter.
      That is, if the parameter is a letter, it returns the upper-case version.
      If the parameter is not a letter, it just returns a copy of the parameter.
     */

    public class Ch4p1 {

        public static void main(String[] args) {
            String line;  // Line of text entered by user.
            System.out.println("Enter a line of text.");
            line = TextIO.getln();
            System.out.println();
            System.out.println("Capitalized version:");
            printCapitalized( line );
        }

        /*
         *  Print a copy of a string to standard output, with the first letter
         *  of each word in the string changed to upper case.
         *  @param str the string that is to be output in capitalized form
         */
        static void printCapitalized( String str ) {
            char ch;       // One of the characters in str.
            char prevCh;   // The character that comes before ch in the string.
            int i;         // A position in str, from 0 to str.length()-1.
            prevCh = '.';  // Prime the loop with any non-letter character.
            for ( i = 0;  i < str.length();  i++ ) {
                ch = str.charAt(i);
                if ( Character.isLetter(ch)  &&  ! Character.isLetter(prevCh) )
                    System.out.print( Character.toUpperCase(ch) );
                else
                    System.out.print( ch );
                prevCh = ch;  // prevCh for next iteration is ch.
            }
            System.out.println();
        }

    } // end CapitalizeOneString

}
