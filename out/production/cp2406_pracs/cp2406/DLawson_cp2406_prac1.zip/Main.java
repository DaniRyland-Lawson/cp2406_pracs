package cp2406;

public class Main {

    public static void main(String[] args) {
        System.out.println("******           *************        **********\n" +
                "**    **                **            **\n" +
                "**     **               **            **\n" +
                "**      **              **            **\n" +
                "**      **              **            ********\n" +
                "**      **       **     **            **\n" +
                "**     **         **    **            **\n" +
                "**    **           **  **             **\n" +
                "*****               ****              ********** \n");
	// write your code here
    }
}
